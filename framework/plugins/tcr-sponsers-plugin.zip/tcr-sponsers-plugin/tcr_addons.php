<?php
/**
* Plugin Name: TCR Sponser plugin
* Description: TCR Sponser plugin for sponser management
* Version: 1.0
* Author: Stig WS
*Text Domain: tcr-sponser-plugin
*/
  
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
    die( 'You shouldnt be here' );
}

//Including file that manages all template

//All Post type include here

$dir = plugin_dir_path( __FILE__ );

//For Client
require_once $dir .'/post-type/sponsor.php';
?>